IRON & BRINE
A Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

One of my growing family of stressed-and-weathered poster fonts, IRON & BRINE feels a bit ocean-going to me for some reason, hence the name (and it's my second font with "Iron" in the title, since I did "IRON LUNG" years back). IRON & BRINE is a full-keyboard small-caps font with a pretty good library of non-English characters. Enjoy!

This font is copyright � 2015 by S. John Ross. "Cumberland Games & Diversions" and this font's title are trademarks of S. John Ross. This font is free for private use only. Any public or commercial use, or any use by an organization rather than an individual, requires a license; contact the Cumberland Fontworks via email (sjohn@cumberlandgames.com) or find me on the Web for alternate email addresses if that one isn't working. Additional glyphs, alterations and customizations are available by commission.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.

Version 1.0
http://fonts.cumberlandgames.com
http://private-use.cumberlandgames.com